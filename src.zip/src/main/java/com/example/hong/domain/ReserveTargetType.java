package com.example.hong.domain;

public enum ReserveTargetType {
    CAFE,
    RESTAURANT
}
