package com.example.hong.domain;

public enum SegmentType { AGE, GENDER }
