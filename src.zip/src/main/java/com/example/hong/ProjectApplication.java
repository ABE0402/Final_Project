package com.example.hong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectApplication {

//	@Autowired
//	private FoodSurveyService surveyService;

	public static void main(String[] args) {
		SpringApplication.run(ProjectApplication.class, args);
	}

}
