package com.example.hong.repository;

import com.example.hong.entity.ReviewAspectScore;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewAspectScoreRepository extends JpaRepository<ReviewAspectScore, Long> {
}