package com.example.hong.domain;


public enum ReservationStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}