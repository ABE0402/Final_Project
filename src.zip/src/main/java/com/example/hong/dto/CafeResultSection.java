package com.example.hong.dto;

import java.util.List;

public record CafeResultSection(String cafeName, List<String> menuNames) {

}

