package com.example.hong.domain;

public enum AccountStatus {
    ACTIVE, SUSPENDED
}
