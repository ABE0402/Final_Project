package com.example.hong.domain;

public enum StoreType { CAFE, RESTAURANT }

