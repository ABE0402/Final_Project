package com.example.hong.domain;

public enum UserRole {
    USER, OWNER, ADMIN
}
