package com.example.hong.domain;

public enum EventAction { CLICK, FAVORITE, RESERVE, REVIEW }
