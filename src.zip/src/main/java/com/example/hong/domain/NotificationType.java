package com.example.hong.domain;

public enum NotificationType {
    RESERVATION_CREATED,
    RESERVATION_CONFIRMED,
    RESERVATION_CANCELLED
}
