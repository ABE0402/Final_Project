package com.example.hong.domain;

public enum ApprovalStatus { PENDING, APPROVED, REJECTED
}
