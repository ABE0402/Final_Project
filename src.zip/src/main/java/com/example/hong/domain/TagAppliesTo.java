package com.example.hong.domain;

public enum TagAppliesTo {
    CAFE, RESTAURANT, BOTH
}