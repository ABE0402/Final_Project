package com.example.hong.domain;

public enum Gender { MALE, FEMALE, UNKNOWN }

