package com.example.hong.repository.projection;

public interface CafeIdTagName {
    Long getCafeId();
    String getName();
}